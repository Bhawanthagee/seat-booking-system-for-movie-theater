/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;



import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;
import seat_booking_system_for_theator.main_menu;

/**
 *
 * @author pc
 */
public class Conn {
    
        public Connection getConnection(){
             Connection con = null;
             try{
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root","");
                return con;
            }
                catch(Exception e){
                JOptionPane.showMessageDialog(null,e);
            }
            return con;
        }
   
}
