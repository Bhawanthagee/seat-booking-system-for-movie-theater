/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author pc
 */
public class Admin extends Person{
    private String films;

    public String getFilms() {
        return films;
    }

    public void setFilms(String films) {
        this.films = films;
    }
    
    public void deleteFilm(String film) {
        
    }
    
    public void addFilm(String film) {
        
    }
    
}
