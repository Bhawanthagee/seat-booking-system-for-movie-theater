/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import connection.Conn;
import config.Admin;
import config.Person;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import seat_booking_system_for_theator.main_menu;

/**
 *
 * @author pc
 */
public class AdminLoginBean implements Loginable{

    @Override
    public boolean login(Admin admin) {
        
       try{
            Conn connection= new Conn();
            String sql = "Select * from logindatabase where username = ? and password = ?";
            Connection con=connection.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            
            pst.setString(1,admin.getName());
                        pst.setString(2,admin.getPassword());

            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                con.close();
                return true;
                
            }
            
            else{
                con.close();
                return false;
            }
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        return false;
    }
        
        

    
}
