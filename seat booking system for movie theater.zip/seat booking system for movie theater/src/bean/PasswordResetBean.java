/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import connection.Conn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import seat_booking_system_for_theator.main_menu;

/**
 *
 * @author pc
 */
public class PasswordResetBean {

    public boolean checkUNameandPassword(String ouname,String oPass) throws SQLException {
        try{
            Conn conn=new Conn();
            String sql = "Select * from logindatabase where username = ? and password = ?";
            Connection con=conn.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            
            pst.setString(1,ouname);
                        pst.setString(2,oPass);

            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                return true;
            }
            
            else{
                return false;
            }
            
        }catch(SQLException e){
            e.printStackTrace();
        }
        return false;
    }


    public void updateUserDetails(String nUserName, String nPassword, String oUserName, String oPassword) {
         Statement stmt = null;
        try{
            Conn conn=new Conn();
           
            Connection con=conn.getConnection();
            stmt = con.createStatement();
            String sql = "UPDATE logindatabase SET username = '"+nUserName+"',password= '"+nPassword+"' WHERE username='"+oUserName+"'";
            stmt.executeUpdate(sql);
      
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
