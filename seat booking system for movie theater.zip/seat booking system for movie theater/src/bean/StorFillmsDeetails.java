/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 * @author DUSHAN YASIRU
 */
public class StorFillmsDeetails {
    
    private String film1;
    
    private String film2;
    
    private String film3;
    
    private String filmDiscription1;
    
    private String filmDiscription2;
    
    private String filmDiscription3;

    public StorFillmsDeetails(String film1, String film2, String film3, String filmDiscription1, String filmDiscription2, String filmDiscription3) {
        this.film1 = film1;
        this.film2 = film2;
        this.film3 = film3;
        this.filmDiscription1 = filmDiscription1;
        this.filmDiscription2 = filmDiscription2;
        this.filmDiscription3 = filmDiscription3;
    }

    public String getFilm1() {
        return film1;
    }

    public String getFilm2() {
        return film2;
    }

    public String getFilm3() {
        return film3;
    }

    public String getFilmDiscription1() {
        return filmDiscription1;
    }

    public String getFilmDiscription2() {
        return filmDiscription2;
    }

    public String getFilmDiscription3() {
        return filmDiscription3;
    }
    
}
