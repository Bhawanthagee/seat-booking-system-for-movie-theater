/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import connection.Conn;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author pc
 */
public class SeatBooking {
    public void book(String name,int availability) {
        try{
            Conn conn=new Conn();
            String sql = "UPDATE `seat` SET `avalability`="+availability+" WHERE name='"+name+"'";
            Connection con=conn.getConnection();
            Statement stmt = con.createStatement();
      
            stmt.executeUpdate(sql);
            
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
}
